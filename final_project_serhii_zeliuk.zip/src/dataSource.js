export const firebaseLink = "https://react-project-2-try-default-rtdb.firebaseio.com";
// export const firebaseLink = "https://final-react-app-52429-default-rtdb.firebaseio.com";
export const localLink = "http://localhost:3001";